#!/usr/bin/env python3
"""
estimate_Q.py -- estimate the process-noise intensity Q for the IEEE 123-node
feeder from realistic physical load dynamics, and update feeder.npz in place.

Q is the single most consequential input to the trust metric: it sets every
tau_i = sigma_i^2 / (h_i' Q h_i) in Lemma 1, and therefore drives BOTH the
exposure term and (via g_i) the residual term and the age-aware estimator.

The state definition here MUST match build_feeder_npz.py exactly -- same
zero-impedance supernode merge, same slack, same ordering -- or Q will not
align with the columns of H. The script asserts this before writing.

Usage
-----
    python estimate_Q.py                          # defaults, updates feeder.npz
    python estimate_Q.py --dt 1.0 --steps 400 --reps 8
    python estimate_Q.py --freeze-taps            # exclude regulator tap jumps
    python estimate_Q.py --dt-sweep               # test the diffusion assumption
    python estimate_Q.py --dry-run                # diagnostics only, no write

Scenarios simulated (all superimposed, per Part 5 of the design guide)
----------------------------------------------------------------------
  1. diurnal ramp        slow aggregate trend            (minutes-hours)
  2. OU load fluctuation per-load mean-reverting noise    (seconds)
  3. DER / cloud transient  fast large swings on a subset (seconds)
  4. motor-start steps    occasional discrete load steps  (impulsive)
  5. regulator taps       discrete jumps, unless frozen   (impulsive)
"""
from __future__ import annotations
import argparse, json, os, sys, time
import numpy as np
import opendssdirect as dss

MASTER_DEFAULT = "IEEE123Master.dss"
ZI_THRESH = 1e4          # must equal build_feeder_npz.py
SBASE_VA = 1e6           # must equal build_feeder_npz.py


# --------------------------------------------------------------- state map
def solve_base(master: str):
    dss.Text.Command(f'Redirect "{os.path.abspath(master)}"')
    dss.Text.Command("Set Maxiterations=100")
    dss.Solution.Solve()
    if not dss.Solution.Converged():
        sys.exit("ERROR: base power flow did not converge")


def build_state_map():
    """Replicate build_feeder_npz.py's supernode state definition exactly."""
    order = list(dss.Circuit.YNodeOrder())
    N = len(order)

    base_ln = {}
    for b in dss.Circuit.AllBusNames():
        dss.Circuit.SetActiveBus(b)
        kvb = dss.Bus.kVBase()
        for nd in dss.Bus.Nodes():
            base_ln[f"{b}.{nd}".upper()] = kvb * 1000.0
    Vbase = np.array([base_ln[o.upper()] for o in order])

    Yd = np.array(dss.Circuit.SystemY())
    Y = (Yd[0::2] + 1j * Yd[1::2]).reshape(N, N)
    Ypu = Y * (Vbase[:, None] * Vbase[None, :] / SBASE_VA)

    off = np.abs(Ypu - np.diag(np.diag(Ypu)))
    par = list(range(N))

    def find(a):
        while par[a] != a:
            par[a] = par[par[a]]
            a = par[a]
        return a

    for a, b in zip(*np.where(off > ZI_THRESH)):
        ra, rb = find(int(a)), find(int(b))
        if ra != rb:
            par[ra] = rb

    roots = sorted({find(i) for i in range(N)})
    sn_of = {r: k for k, r in enumerate(roots)}
    node2sn = np.array([sn_of[find(i)] for i in range(N)])
    S = len(roots)
    rep = [int(np.where(node2sn == k)[0][0]) for k in range(S)]   # representative node

    slack_nodes = [i for i, o in enumerate(order) if o.upper().startswith("150.")][:3]
    slack = sorted({int(node2sn[i]) for i in slack_nodes})
    theta_idx = [k for k in range(S) if k not in slack]
    n_state = len(theta_idx) + S
    return dict(order=order, N=N, Vbase=Vbase, node2sn=node2sn, S=S,
                rep=rep, slack=slack, theta_idx=theta_idx, n_state=n_state)


def read_state(sm) -> np.ndarray:
    """[theta of non-slack supernodes ; |V| of all supernodes], per unit."""
    v = np.array(dss.Circuit.YNodeVArray())
    vpu = (v[0::2] + 1j * v[1::2]) / sm["Vbase"]
    th = np.angle(vpu)[sm["rep"]]
    vm = np.abs(vpu)[sm["rep"]]
    return np.r_[th[sm["theta_idx"]], vm]


# ------------------------------------------------------------- load handles
def snapshot_loads():
    names, kw, kvar = [], [], []
    if dss.Loads.First() == 0:
        sys.exit("ERROR: no loads found")
    while True:
        names.append(dss.Loads.Name())
        kw.append(dss.Loads.kW())
        kvar.append(dss.Loads.kvar())
        if dss.Loads.Next() == 0:
            break
    return names, np.array(kw), np.array(kvar)


def apply_loads(names, kw, kvar):
    for nm, p, q in zip(names, kw, kvar):
        dss.Loads.Name(nm)
        dss.Loads.kW(float(p))
        dss.Loads.kvar(float(q))


# ---------------------------------------------------------------- scenarios
class LoadDynamics:
    """Superimposed physical mechanisms driving the per-load multiplier."""

    def __init__(self, n_loads, dt, rng, cfg):
        self.n, self.dt, self.rng, self.cfg = n_loads, dt, rng, cfg
        self.ou = np.zeros(n_loads)                       # OU fluctuation state
        self.der = rng.random(n_loads) < cfg.der_fraction  # DER-exposed loads
        self.cloud = 0.0
        self.step_hold = np.zeros(n_loads)
        self.t = 0.0

    def advance(self) -> np.ndarray:
        c, dt, rng = self.cfg, self.dt, self.rng

        # 1. diurnal aggregate ramp (slow trend, %/minute)
        self.t += dt
        diurnal = 1.0 + c.diurnal_rate_per_min * (self.t / 60.0)

        # 2. Ornstein-Uhlenbeck per-load fluctuation (mean-reverting, seconds)
        theta = dt / max(c.ou_tau_s, 1e-9)
        self.ou += -theta * self.ou + c.ou_sigma * np.sqrt(2 * theta) * rng.standard_normal(self.n)

        # 3. DER / cloud transient: common factor on DER-exposed loads
        th_c = dt / max(c.cloud_tau_s, 1e-9)
        self.cloud += -th_c * self.cloud + c.cloud_sigma * np.sqrt(2 * th_c) * rng.standard_normal()
        der_term = np.where(self.der, self.cloud, 0.0)

        # 4. motor-start / switching steps: occasional impulses that persist
        fire = rng.random(self.n) < (c.step_rate_per_s * dt)
        self.step_hold = np.where(fire,
                                  c.step_size * rng.standard_normal(self.n),
                                  self.step_hold * c.step_decay)

        mult = diurnal * (1.0 + self.ou + der_term + self.step_hold)
        return np.clip(mult, c.mult_floor, c.mult_ceiling)


class Cfg:
    # physical defaults for a distribution feeder; override via CLI
    diurnal_rate_per_min = 0.004     # +0.4 %/min aggregate trend
    ou_tau_s = 30.0                  # load fluctuation correlation time
    ou_sigma = 0.04                  # 4 % s.d. per-load fluctuation
    cloud_tau_s = 20.0               # PV cloud-transient correlation time
    cloud_sigma = 0.25               # 25 % swing on DER-exposed loads
    der_fraction = 0.30              # share of loads behind DER/PV
    step_rate_per_s = 0.002          # motor starts per load per second
    step_size = 0.15
    step_decay = 0.98
    mult_floor, mult_ceiling = 0.2, 2.5


# ----------------------------------------------------------------- simulate
def simulate(sm, names, kw0, kvar0, dt, steps, reps, rng, cfg, freeze_taps, verbose=True):
    """Return pooled within-scenario state increments dX."""
    if freeze_taps:
        dss.Text.Command("Set ControlMode=OFF")
    else:
        dss.Text.Command("Set ControlMode=STATIC")

    all_dX, fails = [], 0
    t0 = time.time()
    for r in range(reps):
        dyn = LoadDynamics(len(names), dt, rng, cfg)
        X = []
        for k in range(steps):
            mult = dyn.advance()
            apply_loads(names, kw0 * mult, kvar0 * mult)
            dss.Solution.Solve()
            if not dss.Solution.Converged():
                fails += 1
                continue
            X.append(read_state(sm))
        X = np.asarray(X)
        if len(X) > 1:
            all_dX.append(np.diff(X, axis=0))       # never differences ACROSS reps
        if verbose:
            print(f"   rep {r+1}/{reps}: {len(X)} solved states "
                  f"({time.time()-t0:.1f}s elapsed)")
    apply_loads(names, kw0, kvar0)
    dss.Solution.Solve()
    if fails:
        print(f"   note: {fails} non-converged snapshots dropped")
    return np.vstack(all_dX)


def estimate_Q(dX, dt, shrinkage):
    """Q = cov(dX)/dt, with optional Ledoit-Wolf-style shrinkage to keep it PD."""
    Q = np.cov(dX.T) / dt
    if shrinkage > 0:
        mu = np.trace(Q) / Q.shape[0]
        Q = (1 - shrinkage) * Q + shrinkage * mu * np.eye(Q.shape[0])
    Q = 0.5 * (Q + Q.T)
    ev = np.linalg.eigvalsh(Q)
    if ev[0] < 0:                                  # numerical PSD repair
        Q += np.eye(Q.shape[0]) * (abs(ev[0]) + 1e-18)
    return Q


# --------------------------------------------------------------- diagnostics
def diagnose(Q, H, s2, n_tel=None, label=""):
    """tau_i = sigma_i^2 / (h_i' Q h_i).

    Only TELEMETRY ages: those samples traverse the network and can be stale.
    Pseudo-measurements (load priors, zero-injection constraints) are generated
    locally by the twin every update, so Delta_i == 0 and g_i == 1 for them
    always.  Their tau is therefore reported only for completeness and must NOT
    drive the choice of Q.
    """
    hQh = np.einsum("ij,jk,ik->i", H, Q, H)
    tau = np.where(hQh > 0, s2 / np.maximum(hQh, 1e-300), np.inf)

    def _block(idx, name, judge):
        t = tau[idx]; fin = t[np.isfinite(t)]
        if fin.size == 0:
            print(f"   {name}: no finite tau"); return None
        med = float(np.median(fin))
        print(f"   {name} tau_i {label}: min={fin.min():.4g}s  median={med:.4g}s  "
              f"max={fin.max():.4g}s   (h'Qh==0 on {int(np.sum(~np.isfinite(t)))})")
        if judge:
            gs = "  ".join(f"g({D}s)={1/(1+D/med):.3f}" for D in (0.1, 1.0, 10.0))
            print(f"      {gs}")
            fb = float(np.mean(fin < 10.0))
            print(f"      channels where age bites at 10 s: {100*fb:.1f}%   "
                  f"inert (tau>1000 s): {100*float(np.mean(fin > 1000.0)):.1f}%")
            return med, fb
        return med, None

    print()
    if n_tel is None:
        res = _block(np.arange(len(tau)), "ALL", True)
    else:
        res = _block(np.arange(n_tel), "TELEMETRY (ages)", True)
        _block(np.arange(n_tel, len(tau)), "pseudo    (never ages)", False)
    med, frac_bite = res if res else (np.nan, 0.0)

    if frac_bite is not None and frac_bite < 0.10:
        print("   [WARN] the freshness branch barely activates on TELEMETRY at these ages.")
        print("          Either the feeder is genuinely slow -- then silent drift needs")
        print("          MINUTE-scale starvation, not seconds, so widen Table II -- or the")
        print("          load model is too quiet (raise --ou-sigma / --cloud-sigma).")
    elif frac_bite is not None and frac_bite > 0.90 and med < 0.2:
        print("   [WARN] tau is SMALLER than the reporting period: telemetry is discounted")
        print("          to near-zero after one missed sample, so the metric degenerates to")
        print("          'is it fresh or not'. Consider a faster reporting rate or check that")
        print("          the load model is not unrealistically violent.")
    return tau, (frac_bite or 0.0)


# --------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--master", default=MASTER_DEFAULT)
    ap.add_argument("--npz", default="feeder.npz")
    ap.add_argument("--dt", type=float, default=1.0, help="sampling interval, s")
    ap.add_argument("--steps", type=int, default=400, help="snapshots per repetition")
    ap.add_argument("--reps", type=int, default=6, help="independent repetitions")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--shrinkage", type=float, default=0.05)
    ap.add_argument("--freeze-taps", action="store_true")
    ap.add_argument("--dt-sweep", action="store_true",
                    help="re-estimate at several dt to test the diffusion assumption")
    ap.add_argument("--dry-run", action="store_true")
    # load-model overrides
    for k in ("ou_sigma", "ou_tau_s", "cloud_sigma", "cloud_tau_s",
              "der_fraction", "diurnal_rate_per_min", "step_rate_per_s"):
        ap.add_argument(f"--{k.replace('_','-')}", type=float, default=None)
    a = ap.parse_args()

    cfg = Cfg()
    for k in ("ou_sigma", "ou_tau_s", "cloud_sigma", "cloud_tau_s",
              "der_fraction", "diurnal_rate_per_min", "step_rate_per_s"):
        v = getattr(a, k)
        if v is not None:
            setattr(cfg, k, v)

    print("=" * 72)
    print("estimate_Q.py -- process-noise intensity for the IEEE 123-node feeder")
    print("=" * 72)
    solve_base(a.master)
    sm = build_state_map()
    print(f"   nodes={sm['N']}  supernodes={sm['S']}  states n={sm['n_state']}")

    if not os.path.exists(a.npz):
        sys.exit(f"ERROR: {a.npz} not found -- run build_feeder_npz.py first")
    d = dict(np.load(a.npz, allow_pickle=True))
    H, s2 = d["H"], d["sigma2"]
    if H.shape[1] != sm["n_state"]:
        sys.exit(f"ERROR: state mismatch. H has {H.shape[1]} columns but this script "
                 f"built {sm['n_state']} states. ZI_THRESH/SBASE must match "
                 f"build_feeder_npz.py exactly.")
    print(f"   H is {H.shape} -- state definition MATCHES")

    names, kw0, kvar0 = snapshot_loads()
    print(f"   loads={len(names)}  total={kw0.sum():.1f} kW  {kvar0.sum():.1f} kvar")
    print(f"   model: OU sigma={cfg.ou_sigma:.3f}@{cfg.ou_tau_s:.0f}s  "
          f"cloud={cfg.cloud_sigma:.2f}@{cfg.cloud_tau_s:.0f}s on {cfg.der_fraction:.0%} of loads  "
          f"taps={'FROZEN' if a.freeze_taps else 'active'}")

    rng = np.random.default_rng(a.seed)
    print(f"\nsimulating {a.reps} x {a.steps} snapshots at dt={a.dt}s ...")
    dX = simulate(sm, names, kw0, kvar0, a.dt, a.steps, a.reps, rng, cfg, a.freeze_taps)
    print(f"   pooled increments: {dX.shape[0]} samples x {dX.shape[1]} states")
    if dX.shape[0] < 2 * dX.shape[1]:
        print(f"   [WARN] only {dX.shape[0]} samples for {dX.shape[1]} states -- "
              f"cov is rank-deficient; increase --steps/--reps or raise --shrinkage")

    Q = estimate_Q(dX, a.dt, a.shrinkage)
    print(f"\n   Q: trace={np.trace(Q):.4e}  max diag={np.max(np.diag(Q)):.4e}  "
          f"min eig={np.linalg.eigvalsh(Q)[0]:.3e}")
    n_tel = int(d["n_telemetry"]) if "n_telemetry" in d else None
    tau_new, frac = diagnose(Q, H, s2, n_tel, "(new)")

    if "Q" in d:
        print("\n   --- comparison with the Q currently in the file ---")
        diagnose(d["Q"], H, s2, n_tel, "(old)")

    if a.dt_sweep:
        print("\n" + "=" * 72)
        print("diffusion-assumption check (Assumption 5): is Q invariant to dt?")
        print("=" * 72)
        for dts in (0.5, 1.0, 2.0, 5.0):
            r2 = np.random.default_rng(a.seed + 99)
            dXs = simulate(sm, names, kw0, kvar0, dts, max(120, a.steps // 3),
                           2, r2, cfg, a.freeze_taps, verbose=False)
            Qs = estimate_Q(dXs, dts, a.shrinkage)
            hQh = np.einsum("ij,jk,ik->i", H, Qs, H)
            tt = np.where(hQh > 0, s2 / np.maximum(hQh, 1e-300), np.inf)
            print(f"   dt={dts:4.1f}s  trace(Q)={np.trace(Qs):.4e}  "
                  f"median tau={np.median(tt[np.isfinite(tt)]):.4g}s")
        print("   A true diffusion gives dt-invariant Q. Strong drift with dt means the")
        print("   random-walk model of Assumption 5 is only valid over short horizons.")

    if a.dry_run:
        print("\n--dry-run: feeder.npz NOT modified")
        return 0

    meta = json.loads(str(d["meta"])) if "meta" in d else {}
    meta.update(dict(
        Q_source="estimate_Q.py, physical load dynamics (OU + cloud + steps + diurnal)",
        Q_dt=a.dt, Q_samples=int(dX.shape[0]), Q_reps=a.reps, Q_steps=a.steps,
        Q_shrinkage=a.shrinkage, Q_taps="frozen" if a.freeze_taps else "active",
        Q_model={k: getattr(cfg, k) for k in
                 ("ou_sigma", "ou_tau_s", "cloud_sigma", "cloud_tau_s",
                  "der_fraction", "diurnal_rate_per_min", "step_rate_per_s")},
        tau_median_all_s=float(np.median(tau_new[np.isfinite(tau_new)])),
        tau_median_telemetry_s=float(np.median(
            tau_new[:n_tel][np.isfinite(tau_new[:n_tel])])) if n_tel else None,
        frac_telemetry_age_bites_10s=float(frac),
        ages_note="only telemetry ages; pseudo-measurements are locally generated "
                  "each update so Delta_i = 0 and g_i = 1 for them",
    ))
    d["Q"] = Q
    d["meta"] = json.dumps(meta)
    d["node2sn"] = sm["node2sn"]
    d["theta_idx"] = np.array(sm["theta_idx"])
    d["slack_supernodes"] = np.array(sm["slack"])
    np.savez_compressed(a.npz, **d)
    print(f"\n   updated {a.npz} with the new Q "
          f"(state map also stored for reproducibility)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
