#!/usr/bin/env python3
"""
starvation.py -- generate network starvation patterns for the HELICS co-simulation.

Emits three arms. Only the first `n_telemetry` channels are ever starved;
pseudo-measurements keep p=0, Delta=0, b=inf because they are generated
locally by the twin and never traverse the network.

    Arm C  control, q = 1        matched |M_rx| AND mean age within a stratum,
                                 varying only WHICH channels drop. Proposition 10
                                 then forces AUC_B1 = 0.5 exactly within stratum,
                                 so any advantage of u is pure geometry.

    Arm G  honest test, q measured
                                 correlated link failures whose structure comes
                                 from the FEEDER TOPOLOGY (RTU bursts, backhaul
                                 segment outages), never from leverage ranking.
                                 q is whatever the physics produces.

    Arm T  ADVERSARIAL, quarantined
                                 deliberately targets the high-leverage weak-axis
                                 channels. This is a mechanism/upper-bound study
                                 and an attacker model. It MUST NOT be used for
                                 the F3 verdict -- selecting patterns because they
                                 favour u is precisely the circularity the paper
                                 removed. Reported separately and labelled.

Outputs
-------
    patterns.npz    P, D, B arrays  (n_scenarios x m)  ready for the ns-3 federate
    scenarios.csv   per-scenario metadata (arm, stratum, k, b1, b2, leverage hits)

Usage
-----
    python starvation.py --npz feeder.npz --n-c 300 --n-g 600 --n-t 200
    python starvation.py --report-only          # diagnostics, no files written
"""
from __future__ import annotations
import argparse, json, sys
import numpy as np
import pandas as pd

INF_BW = 1e12          # "unlimited" bandwidth marker for untouched channels


# ------------------------------------------------------------------ helpers
def load_feeder(path):
    d = np.load(path, allow_pickle=True)
    H, s2 = d["H"], d["sigma2"]
    n_tel = int(d["n_telemetry"])
    return d, H, s2, n_tel, H.shape[0], H.shape[1]


def spectrum(H, s2, w):
    A = H * np.sqrt(np.maximum(w, 0.0) / s2)[:, None]
    sv = np.linalg.svd(A, compute_uv=False)
    lam = np.zeros(H.shape[1])
    lam[:min(len(sv), H.shape[1])] = sv[:min(len(sv), H.shape[1])] ** 2
    return np.sort(lam)


def weak_axis_leverage(H, s2, n_tel):
    """Leverage of each TELEMETRY channel on the weakest eigenvector of G_inf.

    G_inf = sum_i K_i with K_i = h_i h_i' / sigma_i^2 (rank-1). If v is the
    eigenvector for lambda_min(G_inf), the leverage of channel i is
        v' K_i v = (h_i . v)^2 / sigma_i^2
    computed in closed form -- the m x n x n tensor is never materialised.
    This reproduces preflight Gate 3's ranking exactly.
    """
    A = H / np.sqrt(s2)[:, None]
    G = A.T @ A
    v = np.linalg.eigh(G)[1][:, 0]                  # weakest direction
    lev = (H @ v) ** 2 / s2
    return lev[:n_tel], v


def home_supernode(H, n_tel, n_state):
    """Physical 'home' of each telemetry channel, inferred from H alone.

    V-magnitude rows have a single 1.0 in the |V| block -> the supernode is read
    off directly. Injection rows are dense, but the diagonal term dominates, so
    the largest-magnitude entry in the |V| block identifies the node. Used only
    to build a plausible co-location structure for correlated failures.
    """
    n_theta = n_state - (n_state + 3) // 2 if False else None
    # |V| block is the trailing S columns; S = (n_state + 3)/2
    S = (n_state + 3) // 2
    Vblk = H[:n_tel, n_state - S:]
    return np.argmax(np.abs(Vblk), axis=1)


def build_groups(H, s2, n_tel, n_state, n_segments, rng):
    """RTU = channels sharing a home supernode. Segment = cluster of RTUs.

    Clustering uses the channels' normalised Jacobian rows, so channels that are
    electrically close land in the same segment. NOTE: this is derived from
    topology/electrical proximity ONLY -- never from weak-axis leverage --
    so Arm G stays honest.
    """
    home = home_supernode(H, n_tel, n_state)
    rtus = {}
    for i, h in enumerate(home):
        rtus.setdefault(int(h), []).append(i)
    rtu_ids = sorted(rtus)
    # segment clustering: k-means on row signatures of each RTU
    sig = np.array([np.abs(H[rtus[r]]).mean(0) for r in rtu_ids])
    sig = sig / (np.linalg.norm(sig, axis=1, keepdims=True) + 1e-30)
    k = min(n_segments, len(rtu_ids))
    cent = sig[rng.choice(len(sig), k, replace=False)]
    for _ in range(25):
        lab = np.argmin(((sig[:, None, :] - cent[None]) ** 2).sum(-1), axis=1)
        for j in range(k):
            if np.any(lab == j):
                cent[j] = sig[lab == j].mean(0)
    segments = {}
    for r, j in zip(rtu_ids, lab):
        segments.setdefault(int(j), []).extend(rtus[r])
    return [rtus[r] for r in rtu_ids], [segments[j] for j in sorted(segments)], home


def blank(m, n_tel):
    """No starvation anywhere; pseudo-measurements stay pristine by construction."""
    return np.zeros(m), np.zeros(m), np.full(m, INF_BW)


# --------------------------------------------------------------------- arms
def arm_C(n_scen, m, n_tel, rng, strata, b_min):
    """Matched-pair control.

    Within a stratum every scenario drops EXACTLY k channels and uses EXACTLY the
    same multiset of ages (a permutation of the same values). Therefore
    |M_rx| and mean-age are IDENTICAL across the whole stratum, so every
    positive/negative pair drawn from it is tied on B1 and B2 -> q = 1 and, by
    Proposition 10, AUC_B1 = 0.5 exactly. Only WHICH channels drop varies, so
    any separation achieved by u is attributable to observability geometry.

    Analyse Arm C WITHIN stratum (stratified AUC); pooling across strata mixes
    different |M_rx| values and would break the q = 1 guarantee.
    """
    rows, P, D, B = [], [], [], []
    per = max(1, n_scen // len(strata))
    for si, (k, age) in enumerate(strata):
        ages = np.full(k, age)                       # identical multiset
        for j in range(per):
            p, d, b = blank(m, n_tel)
            sel = rng.choice(n_tel, k, replace=False)
            p[sel] = 1.0                             # dropped outright
            d[sel] = ages                            # same ages, permuted position
            b[sel] = b_min * 0.5                     # below feasibility
            P.append(p); D.append(d); B.append(b)
            rows.append(dict(arm="C", stratum=si, k=k, age=age,
                             dropped=json.dumps(sorted(int(x) for x in sel))))
    return rows, P, D, B


def arm_G(n_scen, m, n_tel, rng, rtus, segments, cfg, b_min):
    """Honest test: correlated failures from topology, q measured.

    Three physical mechanisms, none of which consults leverage:
      * per-RTU Gilbert-Elliott burst loss (an RTU stays bad for a while)
      * whole-backhaul-segment outage (shared fibre/radio path fails)
      * independent per-channel jitter, giving partial ages rather than drops

    Scenarios are drawn across the three communication regimes of Table II
    (ample / moderate / severe) so the arm spans the operating range rather than
    clustering at one severity. Severity is set by the REGIME, never by which
    channels would hurt most -- the arm stays honest.
    """
    rows, P, D, B = [], [], [], []
    sv = getattr(cfg, "severity", 1.0)
    regimes = [("ample", 0.02*sv, 0.02*sv), ("moderate", 0.15*sv, 0.10*sv),
               ("severe", min(0.45*sv, 0.95), min(0.30*sv, 0.90))]
    for idx in range(n_scen):
        rname, p_seg, p_rtu = regimes[idx % len(regimes)]
        p, d, b = blank(m, n_tel)
        mech = []
        # (a) segment outage
        if rng.random() < p_seg:
            seg = segments[rng.integers(len(segments))]
            p[seg] = 1.0; d[seg] = rng.uniform(*cfg.age_out)
            b[seg] = b_min * 0.5; mech.append("segment")
        # (b) RTU bursts (Gilbert-Elliott: bad state -> high loss)
        for grp in rtus:
            if rng.random() < p_rtu:
                loss = rng.uniform(*cfg.burst_loss)
                if rname == "severe" and rng.random() < 0.5:
                    loss = 1.0                      # RTU fully out
                p[grp] = np.maximum(p[grp], loss)
                d[grp] = np.maximum(d[grp], rng.uniform(*cfg.age_burst))
                mech.append("rtu")
        # (c) background jitter on everything still healthy
        idle = np.arange(n_tel)[p[:n_tel] == 0.0]
        if idle.size:
            p[idle] = rng.uniform(*cfg.base_loss, size=idle.size)
            d[idle] = rng.uniform(*cfg.age_base, size=idle.size)
        P.append(p); D.append(d); B.append(b)
        rows.append(dict(arm="G", stratum=-1, regime=rname,
                         k=int((p[:n_tel] >= 1.0).sum()),
                         age=float(d[:n_tel].mean()),
                         mechanisms=",".join(sorted(set(mech))) or "jitter"))
    return rows, P, D, B


def arm_T(n_scen, m, n_tel, rng, lev, cfg, b_min):
    """ADVERSARIAL / mechanism study -- NOT the F3 verdict.

    Deliberately drops the highest-leverage weak-axis channels. This answers
    'how bad can it get if an attacker chooses the worst channels', and it
    demonstrates the geometry mechanism cleanly. It CANNOT be used to argue that
    u beats B1 in practice, because the patterns were selected precisely because
    they favour u. Kept separate so it can never leak into the F3 statistics.
    """
    rows, P, D, B = [], [], [], []
    order = np.argsort(lev)[::-1]
    for _ in range(n_scen):
        p, d, b = blank(m, n_tel)
        k = int(rng.integers(cfg.t_kmin, cfg.t_kmax + 1))
        frac = rng.uniform(*cfg.t_target_frac)       # share taken from the top
        n_top = max(1, int(round(frac * k)))
        sel = list(order[:n_top])
        rest = [i for i in range(n_tel) if i not in set(sel)]
        sel += list(rng.choice(rest, max(0, k - n_top), replace=False))
        sel = np.array(sel)
        p[sel] = 1.0; d[sel] = rng.uniform(*cfg.age_out)
        b[sel] = b_min * 0.5
        P.append(p); D.append(d); B.append(b)
        rows.append(dict(arm="T", stratum=-1, k=k, age=float(d[:n_tel].mean()),
                         target_frac=frac, n_top=n_top))
    return rows, P, D, B


# ------------------------------------------------------------- q and metrics
def pair_tie_fraction(b1, b2, y, tol=1e-9):
    """q over ALL (positive, negative) pairs -- AUC is an all-pairs quantity.

    q = #{(i,j): y_i=1, y_j=0, B1_i==B1_j and B2_i==B2_j} / (N_pos * N_neg)
    """
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    if pos.size == 0 or neg.size == 0:
        return float("nan")
    tie = (np.abs(b1[pos, None] - b1[None, neg]) <= tol) & \
          (np.abs(b2[pos, None] - b2[None, neg]) <= tol)
    return float(tie.mean())


class GCfg:
    p_segment = 0.15
    p_rtu_bad = 0.08
    burst_loss = (0.25, 0.95)
    base_loss = (0.0, 0.05)
    age_base = (0.0, 0.6)
    age_burst = (0.5, 4.0)
    age_out = (2.0, 10.0)
    t_kmin, t_kmax = 4, 16
    t_target_frac = (0.5, 1.0)


# --------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--npz", default="feeder.npz")
    ap.add_argument("--out-npz", default="patterns.npz")
    ap.add_argument("--out-csv", default="scenarios.csv")
    ap.add_argument("--n-c", type=int, default=300)
    ap.add_argument("--n-g", type=int, default=600)
    ap.add_argument("--n-t", type=int, default=200)
    ap.add_argument("--segments", type=int, default=6)
    ap.add_argument("--g-severity", type=float, default=1.0,
                    help="scale Arm G failure rates if the oracle positive rate is too low")
    ap.add_argument("--b-min", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--report-only", action="store_true")
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)

    d, H, s2, n_tel, m, n_state = load_feeder(a.npz)
    print("=" * 72); print("starvation.py -- pattern generation"); print("=" * 72)
    print(f"  channels m={m}   states n={n_state}   STARVABLE telemetry={n_tel}")
    print(f"  pseudo-measurements {m-n_tel} left untouched (p=0, Delta=0, b=inf)")

    lev, v = weak_axis_leverage(H, s2, n_tel)
    rtus, segments, home = build_groups(H, s2, n_tel, n_state, a.segments, rng)
    print(f"  RTU groups={len(rtus)}  backhaul segments={len(segments)} "
          f"(from electrical proximity, NOT leverage)")
    top = np.argsort(lev)[::-1][:8]
    print(f"  weak-axis leverage: top-8 telemetry channels {top.tolist()}")
    print(f"                      leverage {np.round(lev[top], 4).tolist()}")

    strata = [(8, 3.0), (16, 3.0), (24, 3.0)]
    rows, P, D, B = [], [], [], []
    gcfg = GCfg(); gcfg.severity = a.g_severity
    for fn, args in ((arm_C, (a.n_c, m, n_tel, rng, strata, a.b_min)),
                     (arm_G, (a.n_g, m, n_tel, rng, rtus, segments, gcfg, a.b_min)),
                     (arm_T, (a.n_t, m, n_tel, rng, lev, GCfg(), a.b_min))):
        r, p, dd, b = fn(*args)
        rows += r; P += p; D += dd; B += b
    P, D, B = np.array(P), np.array(D), np.array(B)
    df = pd.DataFrame(rows)

    # per-scenario observables
    rx = (P < 1.0) & (B >= a.b_min)
    df["b1"] = rx[:, :n_tel].mean(1)                       # received fraction
    df["b2"] = D[:, :n_tel].mean(1)                        # mean age
    df["n_dropped"] = (P[:, :n_tel] >= 1.0).sum(1)
    df["lev_hit"] = [(lev[(P[i, :n_tel] >= 1.0)].sum() / lev.sum()) for i in range(len(P))]
    lam0 = spectrum(H, s2, np.ones(m))[0]
    df["lam_ratio"] = [spectrum(H, s2, np.r_[(1 - P[i, :n_tel]), np.ones(m - n_tel)])[0] / lam0
                       for i in range(len(P))]

    # ---- sanity: pseudo-measurements must be pristine ----
    assert np.all(P[:, n_tel:] == 0) and np.all(D[:, n_tel:] == 0) and np.all(B[:, n_tel:] >= INF_BW)
    print("\n  [OK] pseudo-measurement block untouched in every scenario")

    print("\n  per-arm summary")
    print(f"  {'arm':4s} {'n':>5s} {'B1 mean':>9s} {'B1 sd':>8s} {'lam ratio':>10s} "
          f"{'lev hit':>8s}")
    for arm in ("C", "G", "T"):
        s = df[df.arm == arm]
        print(f"  {arm:4s} {len(s):5d} {s.b1.mean():9.4f} {s.b1.std():8.4f} "
              f"{s.lam_ratio.mean():10.4f} {s['lev_hit'].mean():8.4f}")

    # ---- q, using lam_ratio collapse as a PROXY label (true labels come from
    #      the oracle in simulation; this only verifies the design property) ----
    print("\n  q (all-pairs tie fraction) using a proxy label lam_ratio<0.5:")
    for arm in ("C", "G", "T"):
        s = df[df.arm == arm]
        y = (s.lam_ratio.values < 0.5).astype(int)
        if arm == "C":
            for si in sorted(s.stratum.unique()):
                ss = s[s.stratum == si]
                yy = (ss.lam_ratio.values < 0.5).astype(int)
                q = pair_tie_fraction(ss.b1.values, ss.b2.values, yy)
                print(f"     C stratum {si} (k={ss.k.iloc[0]:2d}): q={q:.4f} "
                      f"-> AUC_B1 ceiling {1-q/2 if q==q else float('nan'):.4f}   "
                      f"pos={int(yy.sum())}/{len(yy)}")
        else:
            q = pair_tie_fraction(s.b1.values, s.b2.values, y)
            print(f"     {arm}: q={q:.4f} -> AUC_B1 ceiling {1-q/2:.4f}   "
                  f"pos={int(y.sum())}/{len(y)}")
            if arm == "G" and "regime" in s.columns:
                for rn in ("ample", "moderate", "severe"):
                    ss = s[s.regime == rn]
                    if len(ss):
                        yy = (ss.lam_ratio.values < 0.5).astype(int)
                        print(f"        regime {rn:9s} pos={int(yy.sum()):3d}/{len(ss):3d}"
                              f"   B1 mean={ss.b1.mean():.3f}   lam ratio={ss.lam_ratio.mean():.3f}")

    gpos = ((df.arm == "G") & (df.lam_ratio < 0.5)).sum() / max((df.arm == "G").sum(), 1)
    if gpos < 0.15:
        print(f"\n  [NOTE] Arm G proxy-positive rate is {100*gpos:.1f}%. On this feeder,")
        print( "         realistic correlated failures rarely collapse observability -- that")
        print( "         is itself a reportable finding. The REAL labels come from the oracle")
        print( "         (d(t) > gamma), not from lam_ratio, and will differ. If the oracle")
        print( "         positive rate is too low for stable AUCs, raise --g-severity; do NOT")
        print( "         re-select patterns by leverage, which would turn Arm G into Arm T.")

    print("\n  REMINDER: Arm G is the F3 verdict. Arm C isolates the mechanism.")
    print("            Arm T is ADVERSARIAL and must be reported separately -- its")
    print("            patterns were chosen because they favour u, so using it for")
    print("            F3 would repeat the circularity the paper removed.")

    if a.report_only:
        print("\n--report-only: no files written")
        return 0
    np.savez_compressed(a.out_npz, P=P, D=D, B=B, n_telemetry=n_tel,
                        leverage=lev, home_supernode=home,
                        meta=json.dumps(dict(
                            b_min=a.b_min, seed=a.seed, strata=strata,
                            segments=len(segments), rtus=len(rtus),
                            note="only channels [0,n_telemetry) are starved")))
    df.to_csv(a.out_csv, index=False)
    print(f"\n  wrote {a.out_npz}  (P,D,B each {P.shape})")
    print(f"  wrote {a.out_csv}  ({len(df)} scenarios)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
